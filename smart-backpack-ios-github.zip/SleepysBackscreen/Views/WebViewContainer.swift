import SwiftUI
import WebKit
import CryptoKit

struct WebViewContainer: UIViewRepresentable {

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIView(context: Context) -> WKWebView {
        let contentController = WKUserContentController()

        // Inject the iOS Bridge shim so window.AndroidBridge works transparently
        let bridgeScriptSource = """
        (function() {
            window.__iosBleConnected = false;
            window.AndroidBridge = {
                isBleConnected: function() {
                    return window.__iosBleConnected;
                },
                startScan: function() {
                    window.webkit.messageHandlers.iosBridge.postMessage({ action: 'startScan' });
                },
                disconnect: function() {
                    window.webkit.messageHandlers.iosBridge.postMessage({ action: 'disconnect' });
                },
                sendTrack: function(title, artist, album, duration, artworkUrl) {
                    window.webkit.messageHandlers.iosBridge.postMessage({
                        action: 'sendTrack',
                        title: title,
                        artist: artist,
                        album: album,
                        duration: duration,
                        artworkUrl: artworkUrl
                    });
                },
                sendCustomText: function(text) {
                    window.webkit.messageHandlers.iosBridge.postMessage({
                        action: 'sendCustomText',
                        text: text
                    });
                },
                showToast: function(message) {
                    window.webkit.messageHandlers.iosBridge.postMessage({
                        action: 'showToast',
                        message: message
                    });
                },
                openSpotifyAuth: function(clientId) {
                    window.webkit.messageHandlers.iosBridge.postMessage({
                        action: 'openSpotifyAuth',
                        clientId: clientId
                    });
                },
                getBatteryLevel: function() {
                    return 90;
                }
            };
            console.log("Sleepy's Backscreen iOS Bridge initialized.");
        })();
        """

        let userScript = WKUserScript(source: bridgeScriptSource, injectionTime: .atDocumentStart, forMainFrameOnly: false)
        contentController.addUserScript(userScript)
        contentController.add(context.coordinator, name: "iosBridge")

        let config = WKWebViewConfiguration()
        config.userContentController = contentController
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.backgroundColor = UIColor(red: 0.02, green: 0.02, blue: 0.06, alpha: 1.0)
        webView.isOpaque = false
        webView.scrollView.isScrollEnabled = true
        webView.scrollView.bounces = false
        webView.navigationDelegate = context.coordinator

        context.coordinator.webView = webView
        context.coordinator.setupListeners()

        // Load the local Web/index.html bundle
        if let webFolder = Bundle.main.url(forResource: "Web", withExtension: nil) {
            let indexUrl = webFolder.appendingPathComponent("index.html")
            webView.loadFileURL(indexUrl, allowingReadAccessTo: webFolder)
        } else if let indexUrl = Bundle.main.url(forResource: "index", withExtension: "html") {
            webView.loadFileURL(indexUrl, allowingReadAccessTo: indexUrl.deletingLastPathComponent())
        }

        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    // ── Coordinator ──────────────────────────────────────────────────────────

    class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
        var parent: WebViewContainer
        weak var webView: WKWebView?

        init(_ parent: WebViewContainer) {
            self.parent = parent
        }

        func setupListeners() {
            // BLE connection state changed callback
            BLEManager.shared.onStateChanged = { [weak self] isConnected, deviceName in
                guard let self = self else { return }
                DispatchQueue.main.async {
                    let js = """
                    window.__iosBleConnected = \(isConnected);
                    if (typeof window.onNativeBleState === 'function') {
                        window.onNativeBleState(\(isConnected), '\(deviceName ?? "SMART_BACKPACK_DISPLAY")');
                    }
                    """
                    self.webView?.evaluateJavaScript(js, completionHandler: nil)
                }
            }

            // System music track changed callback
            MusicObserver.shared.onTrackChanged = { [weak self] title, artist, album, duration, position, isPlaying, artworkUrl in
                guard let self = self else { return }
                DispatchQueue.main.async {
                    let safeTitle = title.replacingOccurrences(of: "'", with: "\\'")
                    let safeArtist = artist.replacingOccurrences(of: "'", with: "\\'")
                    let safeAlbum = album.replacingOccurrences(of: "'", with: "\\'")
                    let safeArt = artworkUrl ?? ""

                    let js = """
                    if (typeof window.onNativeTrackChanged === 'function') {
                        window.onNativeTrackChanged(
                            '\(safeTitle)',
                            '\(safeArtist)',
                            '\(safeAlbum)',
                            \(duration),
                            \(position),
                            \(isPlaying),
                            '\(safeArt)'
                        );
                    }
                    """
                    self.webView?.evaluateJavaScript(js, completionHandler: nil)
                }
            }
        }

        // ── WKScriptMessageHandler ───────────────────────────────────────────

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.name == "iosBridge",
                  let body = message.body as? [String: Any],
                  let action = body["action"] as? String else { return }

            switch action {
            case "startScan":
                BLEManager.shared.startScan()

            case "disconnect":
                BLEManager.shared.disconnect()

            case "sendTrack":
                let title = body["title"] as? String ?? ""
                let artist = body["artist"] as? String ?? ""
                let album = body["album"] as? String ?? ""
                let duration = body["duration"] as? Int64 ?? 0
                let artworkUrl = body["artworkUrl"] as? String

                DispatchQueue.global(qos: .userInitiated).async {
                    var image: UIImage? = nil
                    if let art = artworkUrl {
                        if art.hasPrefix("data:image"), let range = art.range(of: "base64,") {
                            let base64 = String(art[range.upperBound...])
                            if let data = Data(base64Encoded: base64) {
                                image = UIImage(data: data)
                            }
                        } else if let url = URL(string: art), art.hasPrefix("http") {
                            if let data = try? Data(contentsOf: url) {
                                image = UIImage(data: data)
                            }
                        }
                    }

                    BLEManager.shared.sendMetadata(
                        title: title,
                        artist: artist,
                        album: album,
                        duration: duration,
                        artwork: image
                    )
                }

            case "sendCustomText":
                if let text = body["text"] as? String {
                    BLEManager.shared.sendCustomText(text: text)
                }

            case "showToast":
                // iOS UI feedback
                if let msg = body["message"] as? String {
                    print("[UI Toast]: \(msg)")
                }

            case "openSpotifyAuth":
                let clientId = body["clientId"] as? String ?? "67a7506c1df741638e55e8842e472289"
                DispatchQueue.main.async {
                    self.presentSpotifyLoginModal(clientId: clientId)
                }

            default:
                break
            }
        }

        private var currentLoginNav: UINavigationController?
        private var currentLoginDelegate: SpotifyLoginNavigationDelegate?

        private func topViewController(base: UIViewController?) -> UIViewController? {
            if let nav = base as? UINavigationController {
                return topViewController(base: nav.visibleViewController)
            }
            if let tab = base as? UITabBarController {
                return topViewController(base: tab.selectedViewController)
            }
            if let presented = base?.presentedViewController {
                return topViewController(base: presented)
            }
            return base
        }

        func presentSpotifyLoginModal(clientId: String) {
            guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                  let rootVC = windowScene.windows.first(where: { $0.isKeyWindow })?.rootViewController else {
                return
            }

            // Generate PKCE code_verifier and code_challenge
            let verifierChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~"
            let codeVerifier = String((0..<64).map { _ in verifierChars.randomElement()! })
            let verifierData = Data(codeVerifier.utf8)
            let hashed = SHA256.hash(data: verifierData)
            let codeChallenge = Data(hashed).base64EncodedString()
                .replacingOccurrences(of: "+", with: "-")
                .replacingOccurrences(of: "/", with: "_")
                .replacingOccurrences(of: "=", with: "")

            let redirectUri = "http://localhost"
            let scope = "user-read-currently-playing%20user-read-playback-state"
            let authUrlString = "https://accounts.spotify.com/authorize?client_id=\(clientId)&response_type=code&redirect_uri=\(redirectUri)&code_challenge_method=S256&code_challenge=\(codeChallenge)&scope=\(scope)&show_dialog=true"
            guard let authUrl = URL(string: authUrlString) else { return }

            let webConfig = WKWebViewConfiguration()
            webConfig.websiteDataStore = WKWebsiteDataStore.default()
            let authWebView = WKWebView(frame: .zero, configuration: webConfig)
            let modalVC = UIViewController()
            modalVC.view = authWebView

            let nav = UINavigationController(rootViewController: modalVC)
            nav.modalPresentationStyle = .formSheet
            modalVC.title = "Connect Spotify"
            modalVC.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(dismissSpotifyModal))

            self.currentLoginNav = nav

            let helper = SpotifyLoginNavigationDelegate(
                clientId: clientId,
                codeVerifier: codeVerifier,
                redirectUri: redirectUri
            ) { [weak self, weak nav, weak modalVC] token, error in
                DispatchQueue.main.async {
                    if let token = token {
                        nav?.dismiss(animated: true) {
                            let js = "window.__onSpotifyConnected && window.__onSpotifyConnected('\(token)');"
                            self?.webView?.evaluateJavaScript(js, completionHandler: nil)
                        }
                    } else if let error = error {
                        let alert = UIAlertController(
                            title: "Spotify Connection",
                            message: "Notice: \(error).\n\nTip: You can also use Apple Music or the built-in player below with zero login required!",
                            preferredStyle: .alert
                        )
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                            nav?.dismiss(animated: true, completion: nil)
                        }))
                        modalVC?.present(alert, animated: true)
                    }
                }
            }
            self.currentLoginDelegate = helper
            authWebView.navigationDelegate = helper
            authWebView.uiDelegate = helper
            authWebView.load(URLRequest(url: authUrl))

            let topVC = self.topViewController(base: rootVC) ?? rootVC
            topVC.present(nav, animated: true)
        }

        @objc func dismissSpotifyModal() {
            currentLoginNav?.dismiss(animated: true, completion: nil)
            currentLoginNav = nil
            currentLoginDelegate = nil
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.allow)
                return
            }

            // Open external links (like Spotify login) in the system browser so app never goes blank
            if url.scheme == "http" || url.scheme == "https" {
                if !url.absoluteString.contains("localhost") && !url.absoluteString.contains("appassets.androidplatform.net") {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                    decisionHandler(.cancel)
                    return
                }
            }

            decisionHandler(.allow)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            // Re-sync initial state
            let isConnected = BLEManager.shared.isConnected
            let js = "window.__iosBleConnected = \(isConnected);"
            webView.evaluateJavaScript(js, completionHandler: nil)
            MusicObserver.shared.fetchCurrentTrack()
        }
    }
}

class SpotifyLoginNavigationDelegate: NSObject, WKNavigationDelegate, WKUIDelegate {
    let clientId: String
    let codeVerifier: String
    let redirectUri: String
    let onResult: (String?, String?) -> Void
    private var hasHandled = false

    init(clientId: String, codeVerifier: String, redirectUri: String, onResult: @escaping (String?, String?) -> Void) {
        self.clientId = clientId
        self.codeVerifier = codeVerifier
        self.redirectUri = redirectUri
        self.onResult = onResult
    }

    private func extractCode(from urlString: String) -> String? {
        if let range = urlString.range(of: "code=") {
            let sub = urlString[range.upperBound...]
            let code = String(sub.prefix(while: { $0 != "&" }))
            return code.isEmpty ? nil : (code.removingPercentEncoding ?? code)
        }
        return nil
    }

    private func extractError(from urlString: String) -> String? {
        if let range = urlString.range(of: "error=") {
            let sub = urlString[range.upperBound...]
            let err = String(sub.prefix(while: { $0 != "&" }))
            return err.removingPercentEncoding ?? err
        }
        return nil
    }

    private func exchangeCodeForToken(code: String) {
        guard !hasHandled else { return }
        hasHandled = true

        guard let tokenUrl = URL(string: "https://accounts.spotify.com/api/token") else {
            onResult(nil, "Invalid token endpoint")
            return
        }

        var request = URLRequest(url: tokenUrl)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let params: [String: String] = [
            "client_id": clientId,
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirectUri,
            "code_verifier": codeVerifier
        ]

        let postBody = params.map { key, value in
            let escapedKey = key.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? key
            let escapedVal = value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? value
            return "\(escapedKey)=\(escapedVal)"
        }.joined(separator: "&")

        request.httpBody = postBody.data(using: .utf8)

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self?.onResult(nil, error.localizedDescription)
                }
                return
            }

            guard let data = data,
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                DispatchQueue.main.async {
                    self?.onResult(nil, "Unable to parse Spotify response")
                }
                return
            }

            if let accessToken = json["access_token"] as? String {
                DispatchQueue.main.async {
                    self?.onResult(accessToken, nil)
                }
            } else if let errorDesc = json["error_description"] as? String {
                DispatchQueue.main.async {
                    self?.onResult(nil, errorDesc)
                }
            } else if let err = json["error"] as? String {
                DispatchQueue.main.async {
                    self?.onResult(nil, err)
                }
            } else {
                DispatchQueue.main.async {
                    self?.onResult(nil, "No access token received")
                }
            }
        }.resume()
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = navigationAction.request.url {
            let urlString = url.absoluteString
            if urlString.contains("localhost") || urlString.contains("127.0.0.1") {
                if let code = extractCode(from: urlString) {
                    decisionHandler(.cancel)
                    exchangeCodeForToken(code: code)
                    return
                } else if let error = extractError(from: urlString) {
                    decisionHandler(.cancel)
                    onResult(nil, error)
                    return
                }
            }
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if let failingURL = (error as NSError).userInfo[NSURLErrorFailingURLStringErrorKey] as? String {
            if let code = extractCode(from: failingURL) {
                exchangeCodeForToken(code: code)
                return
            }
        }
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil {
            webView.load(navigationAction.request)
        }
        return nil
    }
}
